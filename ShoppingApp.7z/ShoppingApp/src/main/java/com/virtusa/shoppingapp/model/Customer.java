package com.virtusa.shoppingapp.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
@Entity
public class Customer implements Serializable {

		private static final long serialVersionUID = 1L;
		
		@Id
		@NotEmpty(message = "*Please enter your phone number")
	    @Pattern(regexp="(^0-9}*") 
		private long phoneNo;
		
		private int roleId=2;
		
		@Column(nullable=false)
	    @NotEmpty(message = "*Please enter your name")
		private String name;
		
		
		@Column(nullable=false)
		@NotEmpty(message = "*Please enter your address")
		private String address;
		
		
		@Pattern(regexp=".+@.+\\.[a-z]+")
		@Column(unique=true)
	    @NotEmpty(message = "*Please enter your email")
		private String email;
		
		@Column(nullable=false)
		@Size(min = 6, max = 8)
	    @Pattern(regexp="(^0-9}*") 
		@NotEmpty(message = "*Please enter your password")
		private String password;
	    
	    
	    @OneToMany(mappedBy="customer") 
	    private Set<Cart> cart;  


	    
		public long getPhoneNo() {
			return phoneNo;
		}
		public void setPhoneNo(long phoneNo) {
			this.phoneNo = phoneNo;
		}
		public int getRoleId() {
			return roleId;
		}
		public void setRoleId(int roleId) {
			this.roleId = roleId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public static long getSerialversionuid() {
			return serialVersionUID;
		}
	    
}
		