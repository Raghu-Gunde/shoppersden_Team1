package com.virtusa.shoppingapp.service.impl;

import java.util.Collection;
import java.util.Collections;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.virtusa.shoppingapp.model.Customer;

public class CustomerDetailsImpl implements UserDetails{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Customer cust;
    
	public CustomerDetailsImpl(Customer cust) {
		super();
		this.cust = cust;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return Collections.singleton(new SimpleGrantedAuthority("USER"));
	}

	@Override
	public String getPassword() {
		return cust.getPassword();
	}

	@Override
	public String getUsername() {
		return cust.getName();
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

}
