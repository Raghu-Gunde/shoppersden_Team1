package com.virtusa.shoppingapp.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity
public class ProductQty implements Serializable   {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int productQtyId;
	
	@Column(nullable=false)
	private int qty;
	
	@Column(nullable=false)
	private double amount;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="cartId",referencedColumnName="cartId")    
	private Cart cart;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="categoryId",referencedColumnName="categoryId")    
	private Category category;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="productId",referencedColumnName="productId")    
	private Product product;
	
	
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getProductQtyId() {
		return productQtyId;
	}

}
