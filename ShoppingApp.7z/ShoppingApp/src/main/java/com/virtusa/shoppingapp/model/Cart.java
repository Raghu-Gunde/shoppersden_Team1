package com.virtusa.shoppingapp.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
@Entity
public class Cart implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cartId;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="phoneNo",referencedColumnName="phoneNo")  
	private Customer customer;
	
	
	
	@OneToMany(mappedBy="cart")
	private  Set<ProductQty> productqty; 
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public int getCartId() {
		return cartId;
	}

}
