package com.virtusa.shoppingapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.shoppingapp.model.Customer;

public interface CustomerRepo extends JpaRepository<Customer, Integer> {
	  Customer findByName(String name);

}
