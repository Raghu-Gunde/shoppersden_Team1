package com.virtusa.shoppingapp.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.virtusa.shoppingapp.model.Customer;
import com.virtusa.shoppingapp.repository.CustomerRepo;
@Service
public class CustomerDetailsService implements UserDetailsService{
	@Autowired
    private CustomerRepo custRepo;
	@Override
	public UserDetails loadUserByUsername(String name) throws UsernameNotFoundException {
		Customer cust = custRepo.findByName(name);
		if(cust==null)
		  throw new UsernameNotFoundException("user 404");
		return new CustomerDetailsImpl(cust);
	}

}
