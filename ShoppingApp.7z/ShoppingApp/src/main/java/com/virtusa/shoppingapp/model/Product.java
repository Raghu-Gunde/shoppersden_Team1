package com.virtusa.shoppingapp.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
@Entity
public class Product implements Serializable  {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int productId;
	
	@Column(nullable=false)
	private String productName;
	
	@Column(nullable=false)
	private String productDesc;
	
	@Column(nullable=false)
	private String ProductPrice;
	
	@Column(nullable=false)
    private String brandName;
	
	@Column(nullable=false)
	private int stock;
	
	
	@Column(nullable=false)
	private String image;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="categoryId",referencedColumnName="categoryId")    
	private Category category;
	
	@OneToMany(mappedBy="product")
	private Set<ProductQty> productqty ;  

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getProductPrice() {
		return ProductPrice;
	}

	public void setProductPrice(String productPrice) {
		ProductPrice = productPrice;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public int getProductId() {
		return productId;
	}
	
	
}
